# Time-wise Unemployment Analysis in India 📊

This project analyzes unemployment trends in India on a month-wise basis.

## 📂 Dataset
The dataset contains two columns:
- `Month`: Monthly timeline (format: YYYY-MM)
- `Unemployment Rate`: Percentage of unemployment

## 📌 Objective
To visualize the trend of unemployment in India over time using Python.

## 📊 Libraries Used
- pandas
- matplotlib
- seaborn

## 🧪 How to Run

1. Clone the repo:
```bash
git clone https://github.com/your-username/timewise-unemployment-analysis.git
```

2. Install dependencies:
```bash
pip install -r requirements.txt
```

3. Run the script:
```bash
python timewise_unemployment_analysis.py
```

## ✅ Conclusion

This project helps understand the impact of different events (like COVID-19) on unemployment trends in India.
