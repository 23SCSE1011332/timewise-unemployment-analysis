import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Load the dataset
df = pd.read_csv('unemployment_data.csv')

# Convert Month column to datetime
df['Month'] = pd.to_datetime(df['Month'])

# Set Month as index
df.set_index('Month', inplace=True)

# Summary Statistics
print("Summary Statistics:")
print(df.describe())

# Plot the unemployment rate over time
plt.figure(figsize=(10, 5))
sns.lineplot(x=df.index, y=df['Unemployment Rate'], marker='o')
plt.title("Time-wise Unemployment Rate in India")
plt.xlabel("Month")
plt.ylabel("Unemployment Rate (%)")
plt.grid(True)
plt.tight_layout()
plt.show()
